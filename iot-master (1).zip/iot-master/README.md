# iot-project
mqtt project

We have changed the alert ranges i.e Temp is above 29, Pressure is above 890, Humidity is above 14
